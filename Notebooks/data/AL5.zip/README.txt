AL5 (MCS 3950, Fall 2026) - twenty raw 1958 aerial photographs of PEI.

Scanned contact prints, reduced from about 3000 px to 1000 px tall (about 3.5 m per pixel).
Names are <flight line>-<frame>. No coordinates.

  16046-17 ... 16046-22    six consecutive frames on flight line 16046
  16046-101 ... 16046-105  five consecutive frames on the neighbouring line
  the other nine           frames from elsewhere on the Island

The hand-drawn ink outlines and letter codes on some prints are 1958 forestry annotations.
