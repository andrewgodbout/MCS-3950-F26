L8 (MCS 3950, Fall 2026) - three handheld phone photos, Panmure Island, PEI (Oct 13, 2025).

Samsung SM-G990W2 main camera, 26 mm equivalent focal length (EXIF), 4:3.
Reduced from 4000 x 3000 to 2000 x 1500 px, so the focal length is about 1502 px.
beach1.jpg, beach2.jpg, beach3.jpg were taken minutes apart while walking along the beach.
